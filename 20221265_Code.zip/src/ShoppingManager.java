import java.util.List;
import java.util.Scanner;

interface ShoppingManager {
    void addProduct(Product product);

    void deleteProductFromConsole(Scanner scanner);

    void removeProduct(Product product);

    void printProductList();

    List<Product> getAllProducts();

    void saveProductsToFile();

    Product findProductById(String productId);
}
