import java.io.Serializable;

class Electronics extends Product implements Serializable {
    private String brand;
    private String warrantyPeriod;;

    public Electronics(){
        // default constructor for serialization without that save part not working correctly.
    }

    public Electronics(String productId, String productName, int availableItems, double price, String brand, String warrantyPeriod) {
        super(productId, productName, availableItems, price);
        this.brand = brand;
        this.warrantyPeriod = warrantyPeriod;
    }
    @Override
    public String getProductType() {
        return "Electronics ";
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getWarrantyPeriod() {
        return warrantyPeriod;
    }

    public void setWarrantyPeriod(String warrantyPeriod) {
        this.warrantyPeriod = warrantyPeriod;
    }
}
/*
    This is the Electronics subclass extending the Product class.
    It includes the specific attributes (brand and warrantyPeriod)
    along with their getter/setter methods and implements the displayInfo method.*/
