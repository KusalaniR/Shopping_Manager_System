import javax.swing.*;
import java.awt.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;
import java.util.HashMap;
import java.util.Map;



public class ShoppingCartPanel extends JPanel {
    private WestminsterShoppingManager shoppingManager;
    private DefaultTableModel tableModel;
    private JTable cartTable;
    private List<Product> cart;

    private Product selectedProduct;
    private boolean isFirstPurchase = true;  // Declare isFirstPurchase at the class level

    private JLabel totalLabel;
    private JLabel firstPurchaseDiscountLabel;
    private JLabel threeItemsDiscountLabel;
    private JLabel finalTotalLabel;

    public ShoppingCartPanel(WestminsterShoppingManager shoppingManager) {
        this.shoppingManager = shoppingManager;

        // Add your shopping cart components and logic here
        JLabel cartLabel = new JLabel("Shopping Cart");

        // Creating a table with columns: "Product", "Quantity", "Price"
        String[] columnNames = {"Product", "Quantity", "Price"};
        tableModel = new DefaultTableModel(columnNames, 0); // 0 rows initially

        cartTable = new JTable(tableModel);
        JScrollPane cartScrollPane = new JScrollPane(cartTable);

        totalLabel = new JLabel("Total  -");
        firstPurchaseDiscountLabel = new JLabel("First Purchase Discount (10%)  -");
        threeItemsDiscountLabel = new JLabel("Three items in the same Category Discount (20%)  -");
        finalTotalLabel = new JLabel("Final Total  -");

        setLayout(new BorderLayout());
        add(cartLabel, BorderLayout.NORTH);
        add(cartScrollPane, BorderLayout.CENTER);

        JPanel southPanel = new JPanel(new GridLayout(4, 1));
        southPanel.add(totalLabel);
        southPanel.add(firstPurchaseDiscountLabel);
        southPanel.add(threeItemsDiscountLabel);
        southPanel.add(finalTotalLabel);

        add(southPanel, BorderLayout.SOUTH);

        // Set the preferred size of the panel
        setPreferredSize(new Dimension(450, 450));
    }

    private int findProductRow(Product product) {
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if (tableModel.getValueAt(i, 0).equals(product.getProductName())) {
                return i;
            }
        }
        return -1;
    }

    public void setSelectedProduct(Product product) {
        this.selectedProduct = product;
    }

    public void updateCart() {
        if (selectedProduct != null) {
            // Update quantity and total price in the cart table
            int row = findProductRow(selectedProduct);
            if (row != -1) {
                int quantity = (int) tableModel.getValueAt(row, 1) + 1;
                double totalPrice = quantity * selectedProduct.getPrice();
                tableModel.setValueAt(quantity, row, 1);
                tableModel.setValueAt(totalPrice, row, 2);

                // Update the labels
                updateLabels();
            } else {
                // Add a new row to the cart table
                Object[] rowData = {selectedProduct.getProductName(), 1, selectedProduct.getPrice()};
                tableModel.addRow(rowData);

                // Update the labels
                updateLabels();
            }

            // Mark the first purchase as completed
            isFirstPurchase = false;
        }
    }

    private void updateLabels() {
        double fullTotal = calculateFullTotal();
        double discountedTotal = calculateDiscountedTotal(fullTotal);
        totalLabel.setText("Total  - " + fullTotal);
        firstPurchaseDiscountLabel.setText("First Purchase Discount (10%)  - " + calculateFirstPurchaseDiscount(discountedTotal));

        double threeItemsDiscount = calculateThreeItemsDiscount();
        threeItemsDiscountLabel.setText("Three items in the same Category Discount (20%)  - " + threeItemsDiscount);

        double finalTotal = discountedTotal - threeItemsDiscount;
        finalTotalLabel.setText("Final Total  - " + finalTotal);

    }

    private double calculateThreeItemsDiscount() {
        // Create a map to store the count of items for each category
        Map<String, Integer> categoryCountMap = new HashMap<>();

        // Iterate through the cart table
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            String productName = (String) tableModel.getValueAt(i, 0);
            String category = getCategoryFromProductName(productName);
            categoryCountMap.put(category, categoryCountMap.getOrDefault(category, 0) + 1);
        }

        // Calculate the discount for each category
        double threeItemsDiscount = 0.0;
        for (String category : categoryCountMap.keySet()) {
            int itemCount = categoryCountMap.get(category);
            if (itemCount >= 3) {
                threeItemsDiscount += calculateCategoryDiscount(category);
            }
        }

        return threeItemsDiscount;
    }

    private double calculateCategoryDiscount(String category) {
        // Calculate the 20% discount for each category with at least three items
        double categoryDiscount = 0.0;

        // Iterate through the cart table to find products in the specified category
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            String productName = (String) tableModel.getValueAt(i, 0);
            if (getCategoryFromProductName(productName).equals(category)) {
                categoryDiscount += 0.2 * (double) tableModel.getValueAt(i, 2);
            }
        }

        return categoryDiscount;
    }

    private String getCategoryFromProductName(String productName) {
        // You may need to modify this method based on your product naming convention
        // This is a simple example assuming that the category is the first word in the product name
        String[] parts = productName.split(" ");
        if (parts.length > 0) {
            return parts[0];
        }
        return "";
    }


    private double calculateFullTotal() {
        double fullTotal = 0.0;
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            double totalPrice = (double) tableModel.getValueAt(i, 2);
            fullTotal += totalPrice;
        }
        return fullTotal;
    }

    private double calculateDiscountedTotal(double fullTotal) {
        // Apply the first purchase discount
        if (isFirstPurchase) {
            return fullTotal * 0.9; // 10% discount for the first purchase
        } else {
            return fullTotal;
        }
    }

    private double calculateFirstPurchaseDiscount(double discountedTotal) {
        // Calculate the first purchase discount
        if (isFirstPurchase) {
            return calculateFullTotal() * 0.1; // 10% discount for the first purchase
        } else {
            return 0.0;
        }
    }

    // ... (other methods remain unchanged)
}
