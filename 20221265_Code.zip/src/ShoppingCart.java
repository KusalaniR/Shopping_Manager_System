import java.io.Serializable;
import java.util.*;

public class ShoppingCart implements Serializable {
    private List<Product> items;
    private Map<String, Integer> categoryCounts;
    private boolean firstPurchase;

    public ShoppingCart() {
        this.items = new ArrayList<>();
        this.categoryCounts = new HashMap<>();
        this.firstPurchase = true;
    }

    public List<Product> getItems() {
        return new ArrayList<>(items);
    }

    public double calculateTotalPrice() {
        double totalPrice = 0;

        for (Product item : items) {
            totalPrice += item.getPrice();
        }

        // Apply discounts
        totalPrice -= calculateCategoryDiscount();
        totalPrice -= calculateFirstPurchaseDiscount();

        return Math.max(totalPrice, 0); // Ensure the total price is non-negative
    }

    private double calculateCategoryDiscount() {
        double categoryDiscount = 0;

        for (Map.Entry<String, Integer> entry : categoryCounts.entrySet()) {
            int itemCount = entry.getValue();
            if (itemCount >= 3) {
                // Apply 20% discount for each category with at least three items
                categoryDiscount += itemCount * 0.2 * items.stream()
                        .filter(product -> product.getProductType().equalsIgnoreCase(entry.getKey()))
                        .mapToDouble(Product::getPrice)
                        .sum();
            }
        }

        return categoryDiscount;
    }

    private double calculateFirstPurchaseDiscount() {
        if (firstPurchase) {
            // Apply 10% discount for the very first purchase
            firstPurchase = false;
            return 0.1 * items.stream().mapToDouble(Product::getPrice).sum();
        }

        return 0;
    }

    public void addProduct(Product product) {
    }

    public List<Product> getCartItems() {
        return null;
    }

    public Collection<Object> addItem() {
        return null;
    }
}
