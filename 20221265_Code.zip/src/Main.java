import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    private static void openGui(WestminsterShoppingManager shoppingManager) {
        new MyFrame(shoppingManager);
    }

    public static void main(String[] args) {
        WestminsterShoppingManager shoppingManager = new WestminsterShoppingManager();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            shoppingManager.displayMenu();

            try {
                System.out.print("Enter your choice: ");
                choice = scanner.nextInt();
                scanner.nextLine();

                switch (choice) {
                    case 1:
                        shoppingManager.addProductFromConsole(scanner);
                        break;
                    case 2:
                        shoppingManager.deleteProductFromConsole(scanner);
                        break;
                    case 3:
                        shoppingManager.printProductList();
                        break;
                    case 4:
                        shoppingManager.saveProductsToFile();
                        break;
                    case 5:
                        shoppingManager.loadProductsFromFile();
                        break;
                    case 6:
                        openGui(shoppingManager);
                        break;
                    case 0:
                        shoppingManager.saveProductsToFile();
                        System.out.println("Exiting...Have a good day!");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                        System.out.println();
                        break;
                }
            } catch (InputMismatchException e) {
                System.err.println("Invalid input. Please enter a valid integer.");
                System.out.println();
                scanner.nextLine();
                choice = -1;
            }
        } while (choice != 0);

        scanner.close();
    }
}
