import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.DefaultTableModel;

public class MyFrame extends JFrame implements ActionListener {
    private JButton myButton;
    private JComboBox<String> comboBox;
    private JTable productTable;
    private DefaultTableModel tableModel;
    private WestminsterShoppingManager shoppingManager;
    private JTextArea detailsArea;
    private JButton shoppingCartButton;
    private JButton addToCartButton; // Moved declaration here
    private JLabel label;

    private JLabel productIdLabel, categoryLabel, nameLabel, sizeLabel, colorLabel, warrantyLabel, brandLabel;

    private Product selectedProduct;
    private ShoppingCartPanel cartPanel;

    MyFrame(WestminsterShoppingManager shoppingManager) {
        this.shoppingManager = shoppingManager;

        label = new JLabel("Westminster Shopping Center");
        label.setForeground(Color.BLACK);
        label.setVerticalAlignment(JLabel.CENTER);
        label.setHorizontalAlignment(JLabel.CENTER);
        label.setOpaque(true); // Set the label to be opaque
        label.setBackground(Color.GREEN); // Set the background color
        label.setPreferredSize(new Dimension(label.getPreferredSize().width, 30)); // Adjust the height as needed

        String[] items = {"All", "Clothes", "Electronics"};

        cartPanel = new ShoppingCartPanel(shoppingManager);

        comboBox = new JComboBox<>(items);
        comboBox.addActionListener(this);

        myButton = new JButton("Shopping Cart");
        myButton.setFocusable(false);
        myButton.addActionListener(this);

        addToCartButton = new JButton("Add to Cart");
        addToCartButton.setFocusable(false);
        addToCartButton.addActionListener(this);

        // Create a panel for the top of the NORTH area
        JPanel topNorthPanel = new JPanel(new BorderLayout());
        topNorthPanel.add(label, BorderLayout.NORTH);
        shoppingCartButton = new JButton("Shopping Cart");
        shoppingCartButton.setFocusable(false);
        shoppingCartButton.addActionListener(this);
        topNorthPanel.add(shoppingCartButton, BorderLayout.SOUTH);

        // Create a panel for the top of the EAST area
        JPanel topEastPanel = new JPanel(new BorderLayout());
        topEastPanel.add(addToCartButton, BorderLayout.SOUTH);


        // Add JLabels under the "Add to Cart" button
        JPanel labelsPanel = new JPanel(new GridLayout(7, 1));
        productIdLabel = new JLabel("Product Id: ");
        categoryLabel = new JLabel("Category: ");
        nameLabel = new JLabel("Name: ");
        sizeLabel = new JLabel("Size: ");
        colorLabel = new JLabel("Color: ");
        warrantyLabel = new JLabel("Warranty: ");
        brandLabel = new JLabel("Brand: ");

        labelsPanel.add(productIdLabel);
        labelsPanel.add(categoryLabel);
        labelsPanel.add(nameLabel);
        labelsPanel.add(sizeLabel);
        labelsPanel.add(colorLabel);
        labelsPanel.add(warrantyLabel);
        labelsPanel.add(brandLabel);

        topEastPanel.add(labelsPanel, BorderLayout.CENTER);

        tableModel = new DefaultTableModel();
        tableModel.addColumn("Product ID");
        tableModel.addColumn("Name");
        tableModel.addColumn("Category");
        tableModel.addColumn("Price");
        tableModel.addColumn("Info");

        productTable = new JTable(tableModel);

        updateTableData();

        JScrollPane scrollPane = new JScrollPane(productTable);

        detailsArea = new JTextArea();
        detailsArea.setEditable(false);
        detailsArea.setBackground(Color.lightGray);

        productTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                int selectedRow = productTable.getSelectedRow();
                if (selectedRow != -1) {
                    selectedProduct = getProductFromTable(selectedRow);
                    updateLabels(selectedProduct);
                    detailsArea.setText(getProductDetails(selectedProduct));

                    // Pass row ID and name to ShoppingCartPanel
                    cartPanel.setSelectedProduct(selectedProduct);
                }
            }
        });

        this.setTitle("Westminster Shopping Center");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(true);
        this.getContentPane().setBackground(Color.blue);
        this.setLayout(new BorderLayout());
        this.add(topNorthPanel, BorderLayout.NORTH);
        this.add(myButton, BorderLayout.SOUTH);
        this.add(comboBox, BorderLayout.WEST);
        this.add(scrollPane, BorderLayout.CENTER);
        this.add(detailsArea, BorderLayout.SOUTH);
        this.add(topEastPanel, BorderLayout.EAST);
        this.pack();
        this.setVisible(true);
    }

    private void openShoppingCartPanel() {
        cartPanel.updateCart();  // Update the cart when opened
        JFrame cartFrame = new JFrame("Shopping Cart");
        cartFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        cartFrame.getContentPane().add(cartPanel);
        cartFrame.pack();
        cartFrame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == myButton) {
            // Open shopping cart window (replace ShoppingCartWindow with the correct class)
            // new ShoppingCartWindow(shoppingManager);
        }
        if (e.getSource() == comboBox) {
            System.out.println(comboBox.getSelectedItem());
            updateTableData();
        }

        if (e.getSource() == shoppingCartButton) {
            // Handle shopping cart button click
            openShoppingCartPanel();
        }
        if (e.getSource() == addToCartButton) {
            // Handle the "Add to Cart" button click
            if (selectedProduct != null) {
                // Update the ShoppingCartPanel with the selected product
                cartPanel.setSelectedProduct(selectedProduct);
                cartPanel.updateCart();
            }
        }
    }

    private void updateTableData() {
        tableModel.setRowCount(0);

        for (Product product : shoppingManager.getProductList()) {
            if (comboBox.getSelectedItem().equals("All") ||
                    (comboBox.getSelectedItem().equals("Clothes") && product instanceof Clothing) ||
                    (comboBox.getSelectedItem().equals("Electronics") && product instanceof Electronics)) {

                Object[] rowData = {
                        product.getProductId(),
                        product.getProductName(),
                        (product instanceof Electronics ? "Electronics" : "Clothing"),
                        product.getPrice(),
                        getProductInfo(product)
                };
                tableModel.addRow(rowData);
            }
        }

    }

    private String getProductInfo(Product product) {
        if (product instanceof Electronics) {
            return "Brand: " + ((Electronics) product).getBrand() +
                    ", Warranty Period: " + ((Electronics) product).getWarrantyPeriod();
        } else if (product instanceof Clothing) {
            return "Size: " + ((Clothing) product).getSize() +
                    ", Color: " + ((Clothing) product).getColor();
        } else {
            return "N/A";
        }
    }

    private String getProductDetails(Product product) {
        StringBuilder details = new StringBuilder("Selected Product - Details\n");
        details.append("Product ID: ").append(product.getProductId()).append("\n");
        details.append("Category: ").append(product instanceof Electronics ? "Electronics" : "Clothing").append("\n");
        details.append("Name: ").append(product.getProductName()).append("\n");
        details.append("Price: ").append(product.getPrice()).append("\n");

        if (product instanceof Electronics) {
            Electronics electronics = (Electronics) product;
            details.append("Brand: ").append(electronics.getBrand()).append("\n");
            details.append("Warranty Period: ").append(electronics.getWarrantyPeriod()).append("\n");
        } else if (product instanceof Clothing) {
            Clothing clothing = (Clothing) product;
            details.append("Size: ").append(clothing.getSize()).append("\n");
            details.append("Color: ").append(clothing.getColor()).append("\n");
        }

        details.append("Items Available: ").append(product.getAvailableItems()).append("\n");
        return details.toString();
    }

    private Product getProductFromTable(int row) {
        String productId = (String) tableModel.getValueAt(row, 0);
        for (Product product : shoppingManager.getProductList()) {
            if (product.getProductId().equals(productId)) {
                return product;
            }
        }
        return null;
    }

    private void updateLabels(Product product) {
        productIdLabel.setText("Product Id: " + product.getProductId());
        categoryLabel.setText("Category: " + (product instanceof Electronics ? "Electronics" : "Clothing"));
        nameLabel.setText("Name: " + product.getProductName());
        sizeLabel.setText("Size: " + (product instanceof Clothing ? ((Clothing) product).getSize() : "N/A"));
        colorLabel.setText("Color: " + (product instanceof Clothing ? ((Clothing) product).getColor() : "N/A"));
        warrantyLabel.setText("Warranty: " + (product instanceof Electronics ? ((Electronics) product).getWarrantyPeriod() : "N/A"));
        brandLabel.setText("Brand: " + (product instanceof Electronics ? ((Electronics) product).getBrand() : "N/A"));
    }
}
