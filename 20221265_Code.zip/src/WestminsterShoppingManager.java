import java.io.*;
import java.util.*;

public class WestminsterShoppingManager implements ShoppingManager {
    private static final int MAX_PRODUCTS = 50;
    private List<Product> productList; // Add this line to declare the productList

    public List<Product> getProductList() {
        return productList;
    }
    public WestminsterShoppingManager() {
        this.productList = new ArrayList<>();
        loadProductsFromFile();
    }

    public void displayMenu() {
        System.out.println("WELCOME TO WESTMINSTER SHOPPING MANAGER");
        System.out.println("   ******   Menu   ******   ");
        System.out.println("1. Add a new product");
        System.out.println("2. Delete a product");
        System.out.println("3. Print product list");
        System.out.println("4. Save to file");
        System.out.println("5. Load products from file");
        System.out.println("6. Open GUI");
        System.out.println("0. Exit");
        System.out.println();
    }

    void addProductFromConsole(Scanner scanner) {
        boolean validProductType = false;

        do {
            try {
                System.out.print("Enter product type (E or e for Electronics / C or c for Clothing): ");
                String productType = scanner.next();

                if (productType.equalsIgnoreCase("c") || productType.equalsIgnoreCase("e")) {
                    validProductType = true;
                    String productID;
                    while (true) {
                        System.out.print("Enter the product id (e.g: " + productType.toUpperCase() + "1 to " + productType.toUpperCase() + "50 or " + productType.toLowerCase() + "1 to " + productType.toLowerCase() + "50): ");
                        productID = scanner.next();

                        // Check if the entered product ID follows the desired format
                        if (productID.matches("(?i)([ce][1-9]|[ce][1-4][0-9]|[ec]50)")) {
                            // Valid format, break from the loop
                            break;
                        } else {
                            System.out.println("Invalid input. Please enter a valid product ID (e.g: " + productType.toUpperCase() + "1 to " + productType.toUpperCase() + "50 or " + productType.toLowerCase() + "1 to " + productType.toLowerCase() + "50).");
                        }
                    }
                    System.out.print("Enter the product name: ");
                    String name = scanner.next();

                    int availableItem;
                    while (true) {
                        try {
                            System.out.print("Enter the available items: ");
                            availableItem = scanner.nextInt();
                            break;
                        } catch (InputMismatchException e) {
                            System.out.println("Invalid input. Please enter a valid integer for available items.");
                            scanner.nextLine(); // Clear the buffer
                        }
                    }

                    double price;
                    while (true) {
                        try {
                            System.out.print("Enter price: ");
                            price = scanner.nextDouble();
                            break;
                        } catch (InputMismatchException e) {
                            System.out.println("Invalid input. Please enter a valid price.");
                            scanner.nextLine(); // Clear the buffer
                        }
                    }

                    if (productType.equalsIgnoreCase("c")) {
                        String[] validSizes = {"xs", "s", "m", "l", "xl", "xxl"};
                        String size;
                        do {
                            System.out.print("Enter valid size (xs, s, m, l, xl, xxl): ");
                            size = scanner.next().toLowerCase();

                            // Check if the entered size is valid
                            if (Arrays.asList(validSizes).contains(size)) {
                                break;
                            } else {
                                System.out.println("Invalid input. Please enter a valid size.");
                            }
                        } while (!Arrays.asList(validSizes).contains(size));

                        String color;
                        System.out.print("Enter color: ");
                        color = scanner.next();
                        System.out.println();

                        Product product = new Clothing(productID, name, availableItem, price, size, color);
                        addProduct(product);
                    } else if (productType.equalsIgnoreCase("e")) {
                        System.out.print("Enter the brand here: ");
                        String brand = scanner.next();

                        scanner = new Scanner(System.in); // Assuming you have a Scanner object
                        String warrantyPeriod = null;
                        boolean validInput = false;

                        while (!validInput) {
                            System.out.print("Enter warranty period (e.g: '3 years' or '3 months'): ");
                            warrantyPeriod = scanner.nextLine().trim();

                            if (!warrantyPeriod.matches("\\d+\\s*(years?|months?)")) {
                                System.out.println("Invalid input. Please enter a valid warranty period (e.g: '3 years' or '3 months').\n");  // Add \n for a new line
                            } else {
                                validInput = true;
                            }
                        }
                        Product product = new Electronics(productID, name, availableItem, price, brand, warrantyPeriod);
                        addProduct(product);
                    }
                } else {
                    System.out.println("Invalid input. Please enter 'E' for Electronics or 'C' for Clothing.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter the correct data type.");
                scanner.nextLine(); // Clear the buffer
            }
        } while (!validProductType);
    }


    @Override
    public void addProduct(Product product) {
        if (product != null) {
            if (productList.size() < MAX_PRODUCTS) {
                productList.add(product);
                System.out.println("Product added successfully: " + product.getProductName());
                System.out.println();
            } else {
                System.out.println("Cannot add more products. Maximum limit reached.");
            }
        } else {
            System.out.println("Cannot add a null product.");
        }
    }

    @Override
    public void deleteProductFromConsole(Scanner scanner) {
        try {
            while (true) {

                System.out.print("Enter the product id to delete (e.g.,  E1 to E50 / e1 to e50 or C1 to C50 / c1 to c50): ");
                String productIdToDelete = scanner.next();
                System.out.println();

                // Check if the entered product ID follows the desired format
                if (productIdToDelete.matches("(?i)([ce][1-9]|[ce][1-4][0-9]|[ce]50)")) {
                    Product productToDelete = findProductById(productIdToDelete);

                    if (productToDelete != null) {
                        removeProduct(productToDelete);
                        System.out.println("Product deleted successfully.");
                        System.out.println();
                    } else {
                        System.out.println("Product not found: " + productIdToDelete);
                    }

                    break; // Exit the loop if the input is valid
                } else if (productIdToDelete.matches("(?i)([ce]'5''0')")) {
                    // Handle the specific case "e50" or "E50" and continue
                    Product productToDelete = findProductById(productIdToDelete);

                    if (productToDelete != null) {
                        removeProduct(productToDelete);
                        System.out.println("Product deleted successfully.");
                    } else {
                        System.out.println("Product not found: " + productIdToDelete);
                        System.out.println();
                    }

                    break; // Exit the loop if the input is valid
                } else {
                    System.out.println("Invalid input. Please enter a valid product ID (e.g.,  E1 to E50).");
                }
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter the correct ID.");
            scanner.nextLine(); // Clear the buffer
        }
    }


    @Override
    public void removeProduct(Product product) {
        if (productList.remove(product)) {
            System.out.println("Product removed: " + product.getProductName());
            System.out.println("Total number of products left: " + productList.size());
        } else {
            System.out.println("Product not found: " + product.getProductName());
        }
    }

    @Override
    public void printProductList() {
        System.out.println("Product List:");

        try {
            List<Product> productList = getAllProducts();
            productList.sort(Comparator.comparing(Product::getProductName)); // Sort products alphabetically

            for (Product product : productList) {
                System.out.print("Type: " + product.getProductType() + " ID: " + product.getProductId() +
                        ", Name: " + product.getProductName() +
                        ", Available Items: " + product.getAvailableItems() +
                        ", Price: " + product.getPrice());

                if (product instanceof Clothing clothing) {
                    System.out.println(", Size: " + clothing.getSize() + ", Color: " + clothing.getColor());
                    System.out.println();
                } else if (product instanceof Electronics electronics) {
                    System.out.println(", Brand: " + electronics.getBrand() + ", Warranty Period: " + electronics.getWarrantyPeriod() + " years");
                    System.out.println();
                } else {
                    System.out.println();
                }
            }
        } catch (Exception e) {
            System.out.println("An error occurred while processing the product list: " + e.getMessage());
            System.out.println();
        }
    }

    @Override
    public List<Product> getAllProducts() {
        return new ArrayList<>(productList);
    }

    @Override
    public void saveProductsToFile() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("products.txt"))) {
            List<Product> productsToSave = new ArrayList<>();

            for (Product product : productList) {
                if (product instanceof Clothing || product instanceof Electronics) {
                    productsToSave.add(product);
                }
            }

            oos.writeObject(productsToSave);
            System.out.println("Products saved to file successfully.");
            System.out.println();
        } catch (IOException e) {
            System.out.println("Error saving products to file: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    public void loadProductsFromFile() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("products.txt"))) {
            Object obj = ois.readObject();
            if (obj instanceof List) {
                List<Product> loadedProducts = (List<Product>) obj;

                productList.clear(); // Clear the existing list
                productList.addAll(loadedProducts);

                System.out.println("Products loaded from file.");
                System.out.println();
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading products from file: " + e.getMessage());
        }
    }

    @Override
    public Product findProductById(String productId) {
        for (Product product : productList) {
            if (product.getProductId().equals(productId)) {
                return product;
            }
        }
        return null;
    }


}

